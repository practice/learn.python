from distutils.core import setup

setup(
	name = 'nester',
	version = '1.0.0',
	py_modules = ['learn_python_nester'],
	author = 'shawn.won',
	author_email = 'shawn.won@gmail.com',
	url = 'http://blog.jabberstory.net',
	description = 'A simple printer of nested lists',
)
